create view ORDER_DETAILS_EXTENDED as
  SELECT Order_Details.OrderID, Order_Details.ProductID, Products.ProductName, 
    Order_Details.UnitPrice, Order_Details.Quantity, Order_Details.Discount, 
    (((Order_Details.UnitPrice*Quantity*(1-Discount)/100))*100) AS ExtendedPrice
FROM Products INNER JOIN Order_Details ON Products.ProductID = Order_Details.ProductID
/

