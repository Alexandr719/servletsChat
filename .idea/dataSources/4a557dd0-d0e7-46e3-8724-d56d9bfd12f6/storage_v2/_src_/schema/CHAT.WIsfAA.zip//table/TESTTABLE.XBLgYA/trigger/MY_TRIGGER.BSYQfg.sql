create trigger MY_TRIGGER
  before update
  on TESTTABLE
  for each row
  BEGIN
:NEW.id := TESTTABLE_SEQ.NEXTVAL;
END;
/

