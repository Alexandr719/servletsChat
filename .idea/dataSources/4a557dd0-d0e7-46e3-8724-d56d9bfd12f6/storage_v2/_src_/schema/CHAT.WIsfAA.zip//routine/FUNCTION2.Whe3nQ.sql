create FUNCTION FUNCTION2 RETURN VARCHAR2 AS 

BEGIN
 dbms_output.put_line(ISBOSSV2(2, 'рекурсивно'));
 RETURN null;
END FUNCTION2;
/

