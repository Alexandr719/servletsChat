create view CATEGORY_SALES_FOR_1997 as
  SELECT Product_Sales_for_1997.CategoryName, Sum(Product_Sales_for_1997.ProductSales) AS CategorySales
FROM Product_Sales_for_1997
GROUP BY Product_Sales_for_1997.CategoryName
/

