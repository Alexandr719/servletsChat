create view PRODUCTS_ABOVE_AVERAGE_PRICE as
  SELECT Products.ProductName, Products.UnitPrice
FROM Products
WHERE Products.UnitPrice>(SELECT AVG(UnitPrice) From Products)
/

