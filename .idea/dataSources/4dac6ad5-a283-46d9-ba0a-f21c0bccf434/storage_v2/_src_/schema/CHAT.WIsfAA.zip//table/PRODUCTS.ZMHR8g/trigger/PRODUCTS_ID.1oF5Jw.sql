create trigger PRODUCTS_ID
  before insert
  on PRODUCTS
  for each row
  DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT Products_Seq.NEXTVAL INTO tmpVar FROM dual;
   :NEW.ProductID := tmpVar;

END Products_Id;
/

