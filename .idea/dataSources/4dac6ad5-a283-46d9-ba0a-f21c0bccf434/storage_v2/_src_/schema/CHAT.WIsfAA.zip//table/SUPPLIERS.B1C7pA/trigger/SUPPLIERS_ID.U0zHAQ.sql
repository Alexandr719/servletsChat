create trigger SUPPLIERS_ID
  before insert
  on SUPPLIERS
  for each row
  DECLARE
tmpVar NUMBER;
BEGIN
   tmpVar := 0;

   SELECT Suppliers_Seq.NEXTVAL INTO tmpVar FROM dual;
   :NEW.SupplierID := tmpVar;

END Suppliers_Id;
/

