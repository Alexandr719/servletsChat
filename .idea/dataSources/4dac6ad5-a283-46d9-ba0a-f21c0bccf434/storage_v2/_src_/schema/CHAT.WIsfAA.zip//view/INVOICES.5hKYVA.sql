create view INVOICES as
  SELECT Orders.ShipName, Orders.ShipAddress, Orders.ShipCity, Orders.ShipRegion, Orders.ShipPostalCode, 
    Orders.ShipCountry, Orders.CustomerID, Customers.CompanyName AS CustomerName, Customers.Address, Customers.City, 
    Customers.Region, Customers.PostalCode, Customers.Country, 
    (FirstName || ' ' || LastName) AS Salesperson, 
    Orders.OrderID, Orders.OrderDate, Orders.RequiredDate, Orders.ShippedDate, Shippers.CompanyName As ShipperName, 
    Order_Details.ProductID, Products.ProductName, Order_Details.UnitPrice, Order_Details.Quantity, 
    Order_Details.Discount, 
   (((Order_Details.UnitPrice*Quantity*(1-Discount)/100))*100) AS ExtendedPrice,
    Orders.Freight
FROM     Shippers INNER JOIN 
        (Products INNER JOIN 
            (
                (Employees INNER JOIN 
                    (Customers INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID) 
                ON Employees.EmployeeID = Orders.EmployeeID) 
            INNER JOIN Order_Details ON Orders.OrderID = Order_Details.OrderID) 
        ON Products.ProductID = Order_Details.ProductID) 
    ON Shippers.ShipperID = Orders.ShipVia
/

