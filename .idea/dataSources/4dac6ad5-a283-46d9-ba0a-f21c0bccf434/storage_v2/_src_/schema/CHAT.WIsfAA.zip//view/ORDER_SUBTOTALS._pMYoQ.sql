create view ORDER_SUBTOTALS as
  SELECT Order_Details.OrderID, Sum(((Order_Details.UnitPrice*Quantity*(1-Discount)/100))*100) AS Subtotal
FROM Order_Details
GROUP BY Order_Details.OrderID
/

